/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "tim.h"
#include "queue.h"
#include "usart.h"
#include "stdio.h"
#include "string.h"
#include <stdlib.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define BUFFSIZE 50
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
	extern int pwmval;
	extern int task1_flag;
	extern int task2_flag;
	extern int task3_flag;
	extern int IRQ_flag;
	extern int Callback_flag;
	extern char rxBUFF[BUFFSIZE];
	extern char txData[BUFFSIZE];
	extern char rxTASK[BUFFSIZE];
	extern char rxint;
	char FLAG1[]={"HELLO"};
	char FLAG2[]={"So sad"};
	
	uint32_t rx_counter = 0;
	int rx_complete = 0;
/* USER CODE END Variables */
/* Definitions for defaultTask */
osThreadId_t defaultTaskHandle;
const osThreadAttr_t defaultTask_attributes = {
  .name = "defaultTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for LED_Breath */
osThreadId_t LED_BreathHandle;
const osThreadAttr_t LED_Breath_attributes = {
  .name = "LED_Breath",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow1,
};
/* Definitions for Uart_Receive */
osThreadId_t Uart_ReceiveHandle;
const osThreadAttr_t Uart_Receive_attributes = {
  .name = "Uart_Receive",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow7,
};
/* Definitions for Uart_Queue */
osMessageQueueId_t Uart_QueueHandle;
const osMessageQueueAttr_t Uart_Queue_attributes = {
  .name = "Uart_Queue"
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */
void DMA_TransferCompleteCallback(UART_HandleTypeDef *huart,uint8_t rxlen) ;
/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void *argument);
void LED_BreathTask(void *argument);
void Uart_ReceiveTask(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* creation of Uart_Queue */
  Uart_QueueHandle = osMessageQueueNew (100, 10, &Uart_Queue_attributes);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of defaultTask */
  defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);

  /* creation of LED_Breath */
  LED_BreathHandle = osThreadNew(LED_BreathTask, NULL, &LED_Breath_attributes);

  /* creation of Uart_Receive */
  Uart_ReceiveHandle = osThreadNew(Uart_ReceiveTask, NULL, &Uart_Receive_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  /* USER CODE BEGIN StartDefaultTask */
  /* Infinite loop */
  while(1)
	{
		task3_flag++;
		osDelay(100);
	}
  /* USER CODE END StartDefaultTask */
}

/* USER CODE BEGIN Header_LED_BreathTask */
/**
* @brief Function implementing the LED_Breath thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_LED_BreathTask */
void LED_BreathTask(void *argument)
{
  /* USER CODE BEGIN LED_BreathTask */
  /* Infinite loop */
  while(1)
  {
	  task1_flag++;
		  while(pwmval<200)
	  {
		  pwmval++;
		  __HAL_TIM_SetCompare(&htim1,TIM_CHANNEL_1,pwmval);
		  osDelay(5);
	  }
	  while(pwmval)
	  {
		  pwmval--;
		  __HAL_TIM_SetCompare(&htim1,TIM_CHANNEL_1,pwmval);
		  osDelay(5);
	  }
  }
  /* USER CODE END LED_BreathTask */
}

/* USER CODE BEGIN Header_Uart_ReceiveTask */
/**
* @brief Function implementing the Uart_Receive thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Uart_ReceiveTask */
void Uart_ReceiveTask(void *argument)
{
  /* USER CODE BEGIN Uart_ReceiveTask */
  /* Infinite loop */
  // �Ӷ����л�ȡ���ݲ����͵�����
   while(1)
   {
//��ͨ����		
		if (xQueueReceive(Uart_QueueHandle,&txData,portMAX_DELAY) == pdTRUE)
		{
			task2_flag++;
			printf("%s\r\n",txData);
		}
	   
		    
//�����			
 /*  // �����Ĵ�С���ɸ���ʵ�����������
		int blockSize = 10;

		// ������Ҫ����Ŀ���
		int numBlocks = BUFFSIZE / blockSize;
		if ( BUFFSIZE% blockSize != 0) 
		{
			numBlocks++;
		}

		// ������տ����ݲ���������
		for (int i = 0; i < numBlocks; i++) 
		{
			// ���㵱ǰ�����ʼ����
			int startIndex = i * blockSize;
			// ���㵱ǰ��Ĵ�С
			int currentBlockSize = (i == numBlocks - 1) ? (BUFFSIZE - startIndex) : blockSize;
			// �Ӷ����н�����Ϣ������
			int* messageBuffer;
			xQueueReceive(Uart_QueueHandle, &messageBuffer, portMAX_DELAY);
			// ����Ϣ�����������ݸ��Ƶ������������Ӧλ��
			memcpy(&txData[startIndex], messageBuffer, currentBlockSize * sizeof(int));
			// �ͷ���Ϣ���������ڴ�
			free(messageBuffer);
		}
		printf("%s\r\n",txData);
*/
	}
	
  /* USER CODE END Uart_ReceiveTask */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

void DMA_TransferCompleteCallback(UART_HandleTypeDef *huart,uint8_t rxlen) 
{
//��ͨ����
		int i=0;
		Callback_flag++;
		if(huart==&huart1)
		{
			for(i=0;i<50;i++)	rxTASK[i]=rxBUFF[i];
			xQueueSendToBackFromISR(Uart_QueueHandle,(u8*)&rxTASK,NULL);				  
			memset(rxBUFF,'\0',BUFFSIZE);				  
			HAL_UART_Receive_DMA(&huart1,(u8*)&rxBUFF,BUFFSIZE);//���´�DMA����			   
		}
//�����
/*	// �����Ĵ�С���ɸ���ʵ�����������
	int blockSize = 10;

	// ������Ҫ����Ŀ���
	int numBlocks = BUFFSIZE / blockSize;
	if ( BUFFSIZE% blockSize != 0) 
	{
		numBlocks++;
	}
	int i=0;
	Callback_flag++;
	if(huart==&huart1)
	{
		for(i=0;i<50;i++)rxTASK[i]=rxBUFF[i];
		// ������������
		for (int i = 0; i < numBlocks; i++) 
		{
			// ���㵱ǰ�����ʼ����
			int startIndex = i * blockSize;
			// ���㵱ǰ��Ĵ�С
			int currentBlockSize = (i == numBlocks - 1) ? (BUFFSIZE - startIndex) : blockSize;
			// ������Ϣ������
			int* messageBuffer = (int*)malloc(currentBlockSize * sizeof(int));
			// �������ݸ��Ƶ���Ϣ������
			memcpy(messageBuffer, &rxTASK[startIndex], currentBlockSize * sizeof(int));
			// ����Ϣ���������
			xQueueSendToBackFromISR(Uart_QueueHandle, &messageBuffer, NULL );
			free(messageBuffer);
		}
	  
	  memset(rxBUFF,'\0',BUFFSIZE);
	  
	  HAL_UART_Receive_DMA(&huart1,(u8*)&rxBUFF,BUFFSIZE);//���´�DMA����
	   
	}
*/

}
/* USER CODE END Application */

